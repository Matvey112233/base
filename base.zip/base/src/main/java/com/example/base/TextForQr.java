package com.example.base;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class TextForQr {
    public static String TakeFromBD(Long ID) {

        String txt = "";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver").getDeclaredConstructor().newInstance();

            try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/practice_statements", "root", "root")) {

                Statement statement = conn.createStatement();
                String sql = "SELECT * FROM practice_statements.products where id = " + ID;
                ResultSet resultSet = statement.executeQuery(sql);
                while (resultSet.next()) {

                    int id = resultSet.getInt(1);
                    String address = resultSet.getString(2);
                    String applicant = resultSet.getString(3);
                    String contents = resultSet.getString(4);
                    String head = resultSet.getString(5);
                    String note = resultSet.getString(6);
                    String resolution = resultSet.getString(7);
                    String status = resultSet.getString(8);
                    String theme = resultSet.getString(9);

                    txt = "Идентификатор:" + ID +
                            "_ФИО Заявителя:" + applicant +
                            "_ФИО руководителя:" + head +
                            "_Адрес:" + address +
                            "_Тематика" + theme +
                            "_Содержание:" + contents +
                            "_Резолюция:" + resolution +
                            "_Статус:" + status +
                            "_Примечание:" + note;
                }
            }
        }
        catch (Exception ex) {
            System.out.println("Connection failed...");
            txt = "Not found";
            System.out.println(ex);
        }
        return txt;
    }
}
