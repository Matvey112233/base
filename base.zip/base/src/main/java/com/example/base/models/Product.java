package com.example.base.models;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Table(name = "products")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    private Long id;
    @Column(name = "applicant")
    private String applicant;
    @Column(name = "head")
    private String head;
    @Column(name = "address")
    private String address;
    @Column(name = "theme")
    private String theme;
    @Column(name = "contents", columnDefinition = "text")
    private String contents;
    @Column(name = "resolution", columnDefinition = "text")
    private String resolution;
    @Column(name = "status")
    private String status;
    @Column(name = "note")
    private String note;
}
