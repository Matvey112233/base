package com.example.base.controllers;

import com.example.base.QrFunc;
import com.example.base.TextForQr;
import com.example.base.models.Product;
import com.example.base.services.ProductService;
import com.google.zxing.WriterException;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;


import java.io.IOException;


@Controller
@RequiredArgsConstructor
public class ProductController {
    private final ProductService productService;

    @GetMapping("/")
    public String products(@RequestParam(name = "applicant", required = false) String applicant, Model model) {
        model.addAttribute("products", productService.listProducts(applicant));
        return "products";
    }

    @GetMapping("/product/{id}")
    public String productInfo(@PathVariable Long id, Model model) {
        model.addAttribute("product", productService.getProductById(id));
        return "product-info";
    }

    @PostMapping("/qr/create")
    public String createQRCode(@RequestParam String path, @RequestParam Long id, Model model) {
        try {
            String txt = TextForQr.TakeFromBD(id);
            String qrCodePath = QrFunc.СreateQR(txt, 1000, 1000, path, "UTF-8", ErrorCorrectionLevel.H);
            model.addAttribute("qrCodePath", qrCodePath);
        } catch (WriterException | IOException e) {
            model.addAttribute("errorMessage", "Failed to create QR code");
        }
        return "redirect:/";
    }


    @PostMapping("/product/create")
    public String createProduct(Product product, Model model) {

        if (    product.getApplicant().isEmpty() ||
                product.getHead().isEmpty() ||
                product.getAddress().isEmpty() ||
                product.getTheme().isEmpty() ||
                product.getContents().isEmpty() ||
                !product.getResolution().isEmpty() ||
                !product.getStatus().isEmpty() ||
                !product.getNote().isEmpty()) {
            return "redirect:/";
        }
        else {
            productService.saveProduct(product);
            return "redirect:/";
        }

    }


    @PostMapping("/product/delete/{id}")
    public String deleteProduct(@PathVariable Long id) {
        productService.deleteProduct(id);
        return "redirect:/";
    }
}
